"""Platform shim for the HarmonyOS build.

Upstream ``chimerax.atomic_lib._load_libs`` is a Cython module that loads the
per-library shared objects (libatomstruct, libelement, libpyinstance, libtmpl,
libpdbconnect) at import time. This port links those translation units directly
into the extension modules that need them, so there is nothing to load here; the
module exists so the upstream ``import`` in ``atomic_lib/__init__`` succeeds and
so callers of ``load_lib`` get a clear answer instead of an ImportError.

This is a build-configuration difference, not a functional stub: the symbols the
libraries provide are present in the linked extensions (verified by the
``--no-undefined`` link and the symbol audit in reports/atomic-ext-2026-11-17.json).
"""

loaded: dict[str, str] = {}


def load_lib(name: str) -> str:
    """Return the shared object name that would have been loaded.

    Static linking means the library is already inside the importing extension,
    so this reports that fact instead of returning a path.
    """
    return f"static:{name}"


def lib_path(name: str) -> str:
    return load_lib(name)


def python_module_name(name: str) -> str:
    return f"chimerax.atomic_lib.lib{name}"
